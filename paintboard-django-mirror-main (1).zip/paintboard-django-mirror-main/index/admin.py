from django.contrib import admin

# Register your models here.
from index.models import *

admin.site.register(Tokenlist)

admin.site.register(IpSpeed_a)
admin.site.register(IpSpeed_g)